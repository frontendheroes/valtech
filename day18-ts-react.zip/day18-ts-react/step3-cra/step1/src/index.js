import { createRoot } from "react-dom";

createRoot(document.getElementById("root"))
.render(<h1>Welcome to your life</h1>)