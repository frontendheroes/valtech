let redux = require("redux");
let createStore = redux.legacy_createStore;

// action type is a constant name
// action creator is function that returns an action object 
// intial state is intial value of store object
// reducer is a function which has switch cases to call functions based on action type
// store is an object that stores all shared states of your application
// subscribe / unsubscribe to listen to changes of the store 
// dispatch is a method that can take action object 

// ACTION 
const ADDHERO = "ADDHERO";

// ACTION creator
let addhero = function(){
    return {
        type : ADDHERO
    }
};

// INITIAL STATE
let intialState = {
    numberOfHeroes : 0
}

// REDUCER
let reducer = (state = intialState, action)=>{
    switch(action.type){
        case ADDHERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        default : return state
    }
};

let store = createStore(reducer);

console.log("intial value of store ", store.getState() );

let unsubscribe = store.subscribe(()=> console.log("Subscribed ", store.getState() ));

store.dispatch( addhero() );
store.dispatch( addhero() );
store.dispatch( addhero() );
unsubscribe();
console.log("unsubscribed");
store.dispatch( addhero() );
store.dispatch( addhero() );
console.log( store.getState()  );