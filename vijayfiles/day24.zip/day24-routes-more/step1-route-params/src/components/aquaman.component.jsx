function AquamanComp() {
    return (
      <div>
        <h1>Aquaman Component</h1>
      </div>
    );
  }
  
  export default AquamanComp;
  