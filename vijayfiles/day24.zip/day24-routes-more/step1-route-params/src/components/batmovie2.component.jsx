function BatMovie2Comp() {
    return (
      <div>
        <h1>Batman Movie 2 Component</h1>
      </div>
    );
  }
  
  export default BatMovie2Comp;
  