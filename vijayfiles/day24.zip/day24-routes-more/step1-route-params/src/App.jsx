import React,{ useState, Suspense } from "react";
import "./myroutes.css";
import { BrowserRouter, Routes, Route, Link, NavLink } from "react-router-dom"
import HomeComp from "./components/home.component";
/* 
import AquamanComp from "./components/aquaman.component";
import BatmanComp from "./components/batman.component";
import BatMovie1Comp from "./components/batmovie1.component";
import BatMovie2Comp from "./components/batmovie2.component";
import BatMovie3Comp from "./components/batmovie3.component";
import NotFound from "./components/notfound.component";
import SupermanComp from "./components/superman.component";
import WonderWomenComp from "./components/wonderwomen.component"; 
*/

let AquamanComp =     React.lazy( () => import('./components/aquaman.component') );
let BatmanComp  =     React.lazy( ()=> import("./components/batman.component") );
let BatMovie1Comp  =  React.lazy( ()=> import("./components/batmovie1.component") );
let BatMovie2Comp  =  React.lazy( ()=> import("./components/batmovie2.component") );
let BatMovie3Comp =   React.lazy( ()=> import("./components/batmovie3.component") );
let NotFound  =       React.lazy( ()=> import("./components/notfound.component") );
let SupermanComp  =   React.lazy( ()=> import("./components/superman.component") );
let WonderWomenComp  = React.lazy( ()=> import("./components/wonderwomen.component") ); 

function App() {
  let [quantity, setQuantity] = useState(0)
  let activeFun1 = ({isActive})=> isActive ? 'box' : 'plainBox';
  let activeFun2 = ({isActive})=> {
    return {
      width: "200px",
      display: "inline-block",
      backgroundColor: isActive ? "crimson" : "darkorange",
      color:  "papayawhip",
      textAlign: "center",
      padding: "5px",
    }
  };

  return (
    <div>
      <h1>React Routing 101</h1>
      <label htmlFor="qty">Set Quantity for Wonder Women</label>
      <input id="qty" value={quantity} onChange={(evt)=> setQuantity(evt.target.value)} type="range" />
      <b> { quantity }</b>
      <BrowserRouter>
       {/*  <ul>
          <li><Link to="/">Home Component</Link></li>
          <li><Link to="batman">Batman Component</Link></li>
          <li><Link to="superman">Superman Component</Link></li>
          <li><Link to="wonderwomen">Wonder Women Component</Link></li>
          <li><Link to="aquaman">Aquaman Component</Link></li>
          <li><Link to="flash">Flash Component</Link></li>
          <li><Link to="cyborg">Cyborg Component</Link></li>
        </ul> */}

        <ul>
          <li><NavLink end className={activeFun1} to="/">Home Component</NavLink></li>
          <li><NavLink style={ activeFun2 } to="/batman">Batman Component</NavLink></li>
          <li><NavLink className={ activeFun1 } to="/batman/movie1">Batman Movie1</NavLink></li>
          <li><NavLink className={ activeFun1 } to="/batman/movie2">Batman Movie2</NavLink></li>
          <li><NavLink className={ activeFun1 } to="/batman/movie3">Batman Movie3</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box brdr' : 'plainBox' } to="/superman">Superman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/wonderwomen">Wonder Women Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to={"/wonderwomen/"+quantity}>Wonder Women Component with params</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/aquaman">Aquaman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/flash">Flash Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/cyborg">Cyborg Component</NavLink></li>
        </ul>
        
        <Routes>
            {/* <Route path="" element={<h1>welcome home</h1>}/> */}
            <Route path="/" element={<HomeComp/>}/>
            <Route path="/batman" element={<Suspense fallback={<>loading...</>}> <BatmanComp/> </Suspense>}>
                <Route path="/batman/movie1" element={<Suspense fallback={<>loading...</>}> <BatMovie1Comp/> </Suspense>}></Route>
                <Route path="/batman/movie2" element={<Suspense> <BatMovie2Comp/> </Suspense>}></Route>
                <Route path="/batman/movie3" element={<Suspense fallback={<>loading...</>}> <BatMovie3Comp/> </Suspense>}></Route>
            </Route>
            <Route path="/superman" element={<Suspense fallback={<>loading...</>}> <SupermanComp/> </Suspense>}/>
            <Route path="/wonderwomen" element={<Suspense fallback={<>loading...</>}> <WonderWomenComp/></Suspense>}/>
            <Route path="/wonderwomen/:qty" element={<Suspense fallback={<>loading...</>}> <WonderWomenComp/></Suspense>}/>
            <Route path="/aquaman" element={<Suspense fallback={<>loading...</>}> <AquamanComp/></Suspense>}/>
            <Route path="/flash" element={<Suspense fallback={<>loading...</>}> <SupermanComp/></Suspense>} />
            <Route path="*" element={<Suspense fallback={<>loading...</>}> <NotFound/> </Suspense>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;


// npm i react-router-dom
// BrowserRouter
  // Routes
    // Route
      // Component
      // Link
// http://p.ip.fi/ipOW