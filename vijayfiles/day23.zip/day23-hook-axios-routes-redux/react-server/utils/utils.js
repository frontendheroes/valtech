module.exports.errorHandler = function(error){
    if(error){
        console.log("Error ", error)
    }
}