const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
let errorHandler = require("./utils/utils").errorHandler;
const config = require("./config/config.json");
const routes = require("./routes/routes");
//-------------------------------------
let app = express();
let port = process.env.PORT || config.port;
//-------------------------------------
let urlstring = config.dburl.replace("{user}",config.dbuser).replace("{password}",config.password).replace("{dbname}", config.dbname)
mongoose.connect(urlstring)
.then(res=>console.log("DB Connected"))
.catch(error=>errorHandler);
//-------------------------------------
app.use(express.static(__dirname+"/public"))
.use(cors())
.use(express.static(__dirname))
.use(express.json())
.use(routes);
//-------------------------------------
app.listen(port,config.host,errorHandler);
console.log(`server is now ready on ${config.host}:${port}`)
//-------------------------------------