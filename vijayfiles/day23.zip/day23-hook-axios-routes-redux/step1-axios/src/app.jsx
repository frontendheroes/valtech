import Users from "./user.component";

let App = ()=>{
    return <div className="container">
                <h1>Ajax with React Hooks</h1>
                <Users/>    
            </div>
};

export default App;