function WonderWomenComp() {
    return (
      <div>
        <h1>Wonder Women Component</h1>
      </div>
    );
  }
  
  export default WonderWomenComp;
  