module.exports = {
    message : "welcome to valtech"
};