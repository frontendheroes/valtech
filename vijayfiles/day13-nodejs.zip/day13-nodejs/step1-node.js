var message1 = "welcome to your life";
var message2 = ", there's no turning back";
let adder = (num1, num2) =>  num1 + num2 ;

// console.log(message);
// console.log(__dirname);
// console.log(__filename);
/* 
module.exports.message1 = message1;
module.exports.message2 = message2; 
*/
module.exports = { message1, message2, adder }
