var message = require("valtech").message;

console.log(message);