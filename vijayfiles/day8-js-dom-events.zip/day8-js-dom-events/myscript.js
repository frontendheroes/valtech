/* function init(){
    document.getElementsByTagName("h1")[0].textContent = "welcome to your life";
}; */
document.getElementsByTagName("h1")[0].textContent = "welcome to your life";
