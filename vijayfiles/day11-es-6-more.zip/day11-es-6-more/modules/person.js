class Person{
    constructor(hname){
        this.name = hname;
    }
    canWalk(){
        return "I can walk";
    }
 }

 export default Person;