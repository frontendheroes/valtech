<template>
  <div>
    <h2>{{ title.toUpperCase() }}</h2>
    <h2>{{ title.toUpperCase().length }}</h2>
    <h3>{{ age * 20 }}</h3>
    <hr>
    <h2 v-text="title"></h2>
    <div v-html="messagetag"></div>
    <div v-bind:class="dynamicClass">
      hello there
    </div>
    <div v-bind:id="dynamicId">
      hello there
    </div>
    <button v-bind:disabled="show">Click Me</button>
    <input type="checkbox" v-model="show"/>
    <input type="text" v-model="title"/>
    <fieldset v-bind:hidden="!show">
      <legend>Terms and Conditions</legend>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic dicta id rem ipsa distinctio mollitia dolorum aperiam et. Velit atque hic nisi unde vel dignissimos voluptatum quis nostrum officia cumque!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto quod consectetur doloribus assumenda officia velit maiores amet, mollitia hic omnis molestias dolor sed at nam quae dolorum illum magni pariatur?
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure a magni ad tenetur beatae, amet ratione necessitatibus dicta molestiae temporibus exercitationem dolore, voluptatibus qui repellat voluptatum architecto aliquid sint hic.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis voluptatem nobis cupiditate! Neque non minima deleniti soluta molestias, ullam, magnam, dolore dolorum fugiat iste dignissimos laborum praesentium? Sed, accusamus ex.
      </p>
    </fieldset>

    <hr>
    <div v-bind:class="['box', 'brdr']">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem ullam tenetur sint, ea molestiae obcaecati eum labore alias ratione fuga fugiat, sed maiores voluptas rem aperiam sunt dolorum omnis quia.
    </div>
    <div v-bind:class="{ 'pinkbox'  : gender === 'female' }">
      Gender Based Style 
    </div>

    <button v-bind:data-sku="itemid">Item for sale</button>
    <div v-bind:lang="speak">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam magni fugiat sint tenetur, nihil, distinctio quod harum minus, praesentium pariatur necessitatibus aspernatur obcaecati iste? Harum in repudiandae eligendi ut corporis.
    </div>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      title : "Welcome to Valtech_",
      age : 20,
      messagetag : "<span> welcome to <u>your</u> <em> life </em> </span>",
      dynamicClass : "box",
      dynamicId : "player",
      show : false,
      gender : 'female',
      itemid : 100123,
      speak : "fr"
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
#player{
  width: 300px;
  height: 150px;
  background-color: rgb(20, 27, 220);
  color: cornsilk;
  text-align: center;
  line-height: 100px;
}
.box{
  width: 300px;
  height: 150px;
  background-color: crimson;
  color: cornsilk;
  text-align: center;
  line-height: 100px;
  overflow: auto;
}
.brdr{
 border: 5px dashed darkmagenta;
 line-height: 16px;
}
.pinkbox{
  width: 200px;
  height: 100px;
  background-color: pink;
  color: aliceblue;
  font-family: Arial, Helvetica, sans-serif;
}
.bluebox{
  width: 200px;
  height: 100px;
  background-color: cornflowerblue;
  color: aliceblue;
  font-family: Arial, Helvetica, sans-serif;
}
div:lang('fr'){
  background-color: goldenrod;
  color: rgb(35, 26, 14);
}
</style>
