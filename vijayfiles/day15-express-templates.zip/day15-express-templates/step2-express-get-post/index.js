const express = require("express");
let app = express();

app.use(express.urlencoded({ extended : true }));
let herolist =  [];
app.get("/",(req, res)=>{
    res.render("home.ejs",{
        compname : "Valtech",
        herolist
    })
});

app.post("/", (req, res)=>{
    // console.log("post request recieved");
    // console.log(req.body.nhero);
    herolist.push(req.body.nhero);
    res.redirect("/");
    res.end();
    // console.log(herolist)
})


app.listen(5050,"localhost",(err)=>{
    if(err) console.log("Error ", err);
    else console.log("server is now live on localhost:5050")
})