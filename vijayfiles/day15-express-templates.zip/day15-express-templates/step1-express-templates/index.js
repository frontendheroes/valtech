const express = require("express");
let app = express();
// $env:PORT=5000
// set PORT=5000
// export PORT=5000

// settings
app.set("views","templates");
app.set("view engine", "ejs");

// var port = process.env.PORT || 6000;
// console.log(port);
// var server = app.listen(port,"localhost",function(error){
// routes  
app.use(function(req, res, next){
    console.log("Custom Middleware", req.url);
    next();
});

function myfun(){
    console.log("get for home page recieved")
};

app.get("/", myfun, (req, res)=>{
    // res.sendFile(__dirname+"/public/index.html");
    res.render("index", {
        compname : "Valtech",
        message : "welcome to your life"
    });
});
app.get("/about", (req, res)=>{
    // res.sendFile(__dirname+"/public/about.html");
    res.render("about", {
        compname : "Valtech"
    });
});
app.get("/contact", (req, res)=>{
    // res.sendFile(__dirname+"/public/contact.html");
    res.render("contact", {
        compname : "Valtech"
    });
});


app.listen(6060,"localhost",function(error){
    if(error){
        console.log("Error ", error)
    }else{
        // console.log("server is now live on localhost : ",server.address().port );
        console.log(`server is now live on localhost : 6060 `);
    }
});