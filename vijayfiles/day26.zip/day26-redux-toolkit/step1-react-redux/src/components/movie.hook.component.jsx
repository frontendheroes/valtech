import { useDispatch, useSelector } from "react-redux";
import { addMovie, removeMovie } from "../redux";

let MovieHookComp = ()=>{
    const numOfMoviesHook = useSelector( state => state.movies.numOfMovies );
    const dispatch = useDispatch();
    return <div>
                <h2>Movie Hook Component</h2>
                <h3>Total Movie Recruited : { numOfMoviesHook }</h3>
                <button onClick={ ()=> dispatch( addMovie() ) }>Add Movie</button>
                <button onClick={ () => dispatch( removeMovie() ) }>Remove Movie</button>
            </div>
}


export default MovieHookComp;