<template>
  <div>
    <h1>{{ title }}</h1>
    <h1 v-once>{{ title }}</h1>
    Power : 
    <input v-model.number.lazy="power" type="range">{{ power }}
    <br>
    Booster : 
    <input v-model.number.lazy="booster" type="range">{{ booster }}
    <br>
    Total Power : {{ power + booster }}
    <hr>
    <textarea v-model.trim="message"></textarea>
    <br> 
    <p>Message : {{ message }}</p>
    <button @click="changeTitle">Change  title</button>
    <p v-pre> user curley bracess to display power eg, {{ power }}</p>
  </div>
</template>

<script>
export default {
data(){
  return {
    title : "Modifiers",
    power : 0,
    booster : 0,
    message : ''
  }
},
methods : {
  changeTitle(){
    this.title = "changed"
  }
}
}
</script>

<style></style>