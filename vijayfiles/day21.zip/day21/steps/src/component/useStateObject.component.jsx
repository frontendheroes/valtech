import { useState } from "react"

let UseStateObjComp = ()=>{
    let [hero, setHero] = useState({ firstname : "", lastname: "" });
    /* 
    let addHeroInfo = function(){
        setHero({
            firstname : "Tony",
            lastname : "Stark"
        })
    } 
    */
    let addHeroName = function(evt){
        setHero({
            ...hero,
            [evt.target.title] : evt.target.value
        })
    }
   /*  let addHeroLastName = function(evt){
        setHero({
            ...hero,
            lastname : evt.target.value
        })
    } */
    return <div>
                <h1>User State Object Hook Component</h1>
                <h2>First Name : { hero.firstname }</h2>
                <h2>Last Name : { hero.lastname }</h2>
                {/* <button onClick={ addHeroInfo }>Add Hero Info</button> */}
                <label htmlFor="fname"> First Name : <input title="firstname" onChange={(evt)=> addHeroName(evt)} type="text" /> </label>
                <br />
                <label htmlFor="lname"> Last Name : <input title="lastname" onChange={(evt)=> addHeroName(evt)} type="text" /> </label>
            </div>
}
export default UseStateObjComp;