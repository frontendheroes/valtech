import { Component } from "react";
import UseStateComp from "./component/useState.component";
import UseStateAssignmentComp from "./component/useStateAssignment";
import UseStateObjComp from "./component/useStateObject.component";

class App extends Component{
    state = {
        apptitle : "Hooks ?",
    }
    render(){
        return <div className="container">
                <h1>{ this.state.apptitle}</h1>
                <UseStateComp/>
                <UseStateObjComp/>
                <UseStateAssignmentComp/>
               </div>
    }
}

export default App;