<template>
  <div>
    <AppUsers/>
  </div>
</template>

<script>
import AppUsers from "./components/users.vue"

  export default {
    data(){
      return {
        title : "Welcome to VUE Training",
      }
    },
    components: { AppUsers }
  }
</script>

<style>
#app {
  font-family: sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>


<!-- http://p.ip.fi/5T8- -->