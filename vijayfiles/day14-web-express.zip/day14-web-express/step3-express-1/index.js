const express = require("express");
let app = express();
// routes
app.get("/", (req, res)=>{
   /*  
    res.write("hello from express");
    res.end(); 
    */
   res.send("hello from express");
})
let loc = app.listen(function(err){
    if(err) console.log("Error ", err)
    console.log(loc.address());
});
console.log("web server is now live on port 3030");