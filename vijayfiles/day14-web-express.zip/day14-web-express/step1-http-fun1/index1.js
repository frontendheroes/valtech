const http = require("http");
let message = "Welcome to your life";
let server = http.createServer((req, res)=>{
    res.writeHead(200,{
        "Content-Type" : "text/html"
    });
    res.write(`
    <!DOCTYPE html>
    <html lang='en'>
    <head> 
    <meta charset='UTF-8'>  
    <title>Document</title>  
    </head>
    <body>`);
    //----------------------------------------
    res.write(`<h2> ${ message } </h2>`)
    //----------------------------------------
    res.write(`</body> 
                </html>`);
    res.end();
});

server.listen(2020, "localhost", error => {
    if(error){ console.log("Error ", error)}
    else { console.log("server is now live on localhost:2020")}
})