import { Text, View, StyleSheet } from "react-native"

let FirstComp = (props)=>{
    return  <View style={ compstyle.view }>
                <Text>First View</Text>
            </View>
}

let compstyle = StyleSheet.create({
    view : {
        flex : 1,
        backgroundColor : 'orange'
    }
})
export default FirstComp