import { Text, View, StyleSheet } from "react-native"

let ThirdComp = (props)=>{
    return  <View style={ compstyle.view }>
                <Text>Third View</Text>
            </View>
}

let compstyle = StyleSheet.create({
    view : {
        flex : 1,
        backgroundColor : 'blue'
    }
})
export default ThirdComp