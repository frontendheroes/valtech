import { Button, Text, View, StyleSheet } from "react-native"

let Mainapp = (props)=>{
    return  <View>
                <Button  onPress={()=> props.changeState(props.col)} title={'change color to # '+props.col} />
            </View>
}

let compstyle = StyleSheet.create({
    textStyle : {
        fontFamily : "sans-serif",
        fontSize : 24,
        color : 'white'
    },
    btn : {
        backgroundColor : 'white',
        wi
    }
})
export default Mainapp