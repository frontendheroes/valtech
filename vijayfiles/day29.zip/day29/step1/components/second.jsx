import { Text, View, StyleSheet } from "react-native"

let SecondComp = (props)=>{
    return  <View style={ compstyle.view }>
                <Text>Second View</Text>
            </View>
}

let compstyle = StyleSheet.create({
    view : {
        flex : 1,
        backgroundColor : 'red'
    }
})
export default SecondComp