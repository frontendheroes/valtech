import { Image, StyleSheet, Text, View, Dimensions } from "react-native";
/*
import an image and assign it to a variable if you need to use it multiple times 
*/

import ironman from "./assets/images/ironman.jpg";

export default function App(){
  /* 
  console.log( require('./assets/images/antman.jpg') )
   console.log( require('./assets/images/batman.jpg') )
   console.log( require('./assets/images/superman.jpg') )
   console.log( require('./assets/images/hulk.jpg') ) 
   */
	return <View style={ appstyle.bgcol } >
    console.log( Dimensions.get({}) )
      {/*      
      the following code embeds the image and may make your app bigger
      the require code below returns a number 
      */}
            <Image source={ require('./assets/images/antman.jpg') } />
            <Image source={ ironman } />

      {/* 
      To load network images https://picsum.photos/images
      network images wont get their size metadata so we need to add the dimensions

      */}
            <Image source={ { uri : "https://i.picsum.photos/id/866/200/300.jpg?hmac=rcadCENKh4rD6MAp6V_ma-AyWv641M4iiOpe1RyFHeI", width : 300, height : 300 } } />
         </View>
}
const appstyle = StyleSheet.create({
  bgcol  :{
    backgroundColor : 'crimson',
    paddingTop : 50,
    flex : 1
  }
})