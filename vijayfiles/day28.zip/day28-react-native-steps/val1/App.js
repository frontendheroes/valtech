import { Image, Text, View, } from "react-native";
import hulk from "./assets/images/hulk.jpg";
import ironman from "./assets/images/ironman.jpg";

export default function App(){
  let hero = "hulk";
  return <View>
          {/*   
           An Image that is bundled with your app 
            Logo
            Icons
           */}
           <Image source={ require("./assets/images/rajani.jpg")}/>
           <Image source={ ironman } style={{ width: 100, height : 100 }} />
           <Image source={ { uri : 'https://picsum.photos/200', width : 200, height : 200  } } />
           
          </View>
}

// http://p.ip.fi/K8yR