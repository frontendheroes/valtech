import { Component } from "react";
import ChildComp from "./components/childcomp";

class App extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    render(){
        return <div>
                    <h2>Application Component | App's Power { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
                   <ChildComp power={ this.state.power }/>
                </div>
    }
}

export default App;