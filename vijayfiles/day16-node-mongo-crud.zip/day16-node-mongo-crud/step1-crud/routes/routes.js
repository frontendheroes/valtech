const express = require("express");
const Hero = require("../models/hero");

const routes = express.Router();
// READ
routes.get("/data", (req, res)=>{
    Hero.find().then(dbres=>res.json(dbres))
});
setTimeout(function(){

},2000);

// CREATE
routes.post("/data", (req, res)=>{
    let hero = new Hero(req.body);
    console.log(req.body);
    hero.save()
    .then(dbres=>{
        res.send({ message : "hero added to list"})
        console.log("db updated")
    })
    .catch(err=>errorHandler);
});
// UPDATE
routes.post("/update/:hid", (req, res)=>{
    console.log("update request recived")
   Hero.findByIdAndUpdate({_id : req.params.hid})
  .then(dbRes=>{
    console.log(dbRes);
        dbRes.title = req.body.title;
        dbRes.firstname = req.body.firstname;
        dbRes.lastname = req.body.lastname;
        dbRes.save().then(updateRes=>res.send({ message : "hero info updated"} ))
  })
  .catch(error=>errorHandler);
})
// READ UPDATE
routes.get("/edit/:heroid", (req, res)=>{
    Hero.findById({ _id : req.params.heroid }).then(dbres => {
        res.send(dbres)
    })
})
// DELETE
routes.delete("/delete/:hid",(req, res)=>{
    // console.log(  );
    Hero.findByIdAndDelete({ _id : req.params.hid })
    .then(dbRes => res.send({ message : "hero deleted", hero : dbRes.title}))
});

module.exports = routes;