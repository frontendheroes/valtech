const redux = require("redux");
let createStore = redux.legacy_createStore;

// action type is a constant name
const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO";
const SETHERO = "SETHERO";

// action creator is function that returns an action object 
let addhero = () => {
    return { 
        type : ADDHERO 
    }
};
let removehero = () => {
    return { 
        type : REMOVEHERO 
    }
};
let sethero = (num) => {
    return { 
        type : SETHERO,
        payload : num 
    }
};

// intial state is intial value of store object
const initalState = {
    numberOfHeroes : 0
};

// reducer is a function which has switch cases to call functions based on action type
let reducer = (state = initalState, action)=>{
    switch(action.type){
        case ADDHERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVEHERO : return { numberOfHeroes : state.numberOfHeroes - 1 }
        case SETHERO : return { numberOfHeroes : action.payload }
        default : return state 
    }
}
// store is an object that stores all shared states of your application
let store = createStore(reducer);
store.subscribe(function(){
    console.log(store.getState());
})
console.log(store.getState());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(addhero());
store.dispatch(sethero(5));
// subscribe / unsubscribe to listen to changes of the store 
// dispatch is a method that can take action object 