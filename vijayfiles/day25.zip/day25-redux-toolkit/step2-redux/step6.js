const redux = require("redux");
const logger = require("redux-logger").createLogger;

let createStore = redux.legacy_createStore;
let combineReducers = redux.combineReducers;
let bindActionCreators = redux.bindActionCreators;
let applyMiddleware = redux.applyMiddleware;


// action type is a constant name
const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO";
const SETHERO = "SETHERO";
// ------------------------------
const ADDMOVIE = "ADDMOVIE";
const REMOVEMOVIE = "REMOVEMOVIE";
const SETMOVIE = "SETMOVIE";

// action creator is function that returns an action object 
let addhero = () => {
    return { 
        type : ADDHERO 
    }
};
let removehero = () => {
    return { 
        type : REMOVEHERO 
    }
};
let sethero = (num) => {
    return { 
        type : SETHERO,
        payload : num 
    }
};
let addmovie = () => {
    return { 
        type : ADDMOVIE 
    }
};
let removemovie = () => {
    return { 
        type : REMOVEMOVIE 
    }
};
let setmovie = (num) => {
    return { 
        type : SETMOVIE,
        payload : num 
    }
};

// intial state is intial value of store object
const initalHeroState = {
    numberOfHeroes : 0
};
const initalMovieState = {
    numberOfMovies : 0,
};

// reducer is a function which has switch cases to call functions based on action type
let heroReducer = (state = initalHeroState, action)=>{
    switch(action.type){
        case ADDHERO : return {...state, numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVEHERO : return {...state, numberOfHeroes : state.numberOfHeroes - 1 }
        case SETHERO : return {...state, numberOfHeroes : action.payload }
        default : return state 
    }
}
let movieReducer = (state = initalMovieState, action)=>{
    switch(action.type){
        case ADDMOVIE : return {...state, numberOfMovies : state.numberOfMovies + 1 }
        case REMOVEMOVIE : return {...state, numberOfMovies : state.numberOfMovies - 1 }
        case SETMOVIE : return {...state, numberOfMovies : action.payload }
        default : return state 
    }
}
// store is an object that stores all shared states of your application

let rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
});

let store = createStore(rootReducer, applyMiddleware(logger()));

store.subscribe(function(){});
let action = bindActionCreators({ addhero, removehero, sethero, addmovie, removemovie, setmovie },store.dispatch)
action.addhero();
action.removehero();
action.sethero(10);
action.addmovie();
action.removemovie();
action.setmovie(10);
