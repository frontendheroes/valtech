import React from "react"

let FamilyContext = React.createContext()

// let provider = FamilyContext.Provider();
// let consumer = FamilyContext.Consumer();

export default FamilyContext;