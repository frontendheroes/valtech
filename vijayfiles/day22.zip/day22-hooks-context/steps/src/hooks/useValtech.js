let useValtech = (args)=>{
    var message = "Welcome To Valtech";
    if(args == 1){
        return message.toUpperCase();
    }else if(args == 2){
        return message.toLowerCase();
    }else{
        return message;
    }
};
export default useValtech;