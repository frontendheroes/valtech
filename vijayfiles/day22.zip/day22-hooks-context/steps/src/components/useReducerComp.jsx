import { useRef } from "react";
import { useReducer, useState } from "react";

let UseReducerComp = ()=>{

let fname = useRef();
let lname = useRef();
let cname = useRef();
//    let [firstname, setFirstName] = useState("");
let reducerFun = (state, action)=>{
    switch(action.type){
        case "UPDATE_FIRSTNAME" : return { ...state, firstname : action.payload}
        case "UPDATE_LASTNAME" : return { ...state, lastname : action.payload}
        case "UPDATE_CITY" : return { ...state, city : action.payload}
        default : return state;
    }
}
    let [state, dispatch ] = useReducer(reducerFun,{ firstname : '', lastname : "", city : "" });
/*     let [lastname, setLastName] = useState("");
    let [city, setCity] = useState(""); */

    return <div>
                <h3>Use Reducer Hook component</h3>
                <input type="text" ref={fname} />
                <button onClick={ ()=> dispatch({type: "UPDATE_FIRSTNAME", payload : fname.current.value}) }>Set First Name</button>
                <h4>First Name : {state.firstname }</h4>
                <input type="text" ref={lname} />
                <button onClick={ ()=> dispatch({type: "UPDATE_LASTNAME", payload : lname.current.value}) }>Set Last Name</button>
                <h4>Last Name : {state.lastname }</h4>
                <input type="text" ref={cname} />
                <button onClick={ ()=> dispatch({type: "UPDATE_CITY", payload : cname.current.value}) }>Set City Name</button>
                <h4>City Name : {state.city }</h4>
                {/* <button onClick={ ()=> setLastName("Wayne") }>Set First Name</button>
                <h4>Last Name : {lastname }</h4>
                <button onClick={ ()=> setCity("Gotham") }>Set First Name</button>
                <h4>City Name : {city }</h4> */}
            </div>
}

export default UseReducerComp;