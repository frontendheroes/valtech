import { useEffect } from "react";

let UseEffectComp = (props)=> {
    let power = props.state.power;
    let version = props.state.version;
    let rating = props.state.rating;
/* 
    useEffect(()=>{
        console.log("UseEffectComp component mounted", Math.random())
    },[]);
    
    useEffect(()=>{
        console.log("UseEffectComp component's power updated", Math.random())
    },[props.state.power]);

    useEffect(()=>{
        return ()=>{
            console.log("UseEffectComp component unmounted", Math.random())
        }
    },[]); */

/*     useEffect(()=>{
        console.log("UseEffectComp component mounted or updated", Math.random())
        return ()=>{
            console.log("UseEffectComp component unmounted", Math.random())
        }
    },[props.state.power]);
    */
    return <div>
                <h2>UseEffect Hook</h2>
                <h3>Power is : { power }</h3>
                <h3>Version is : { version }</h3>
                <h3>Rating is : { rating }</h3> 
                
            </div>
}
export { UseEffectComp };


// http://p.ip.fi/tTZv