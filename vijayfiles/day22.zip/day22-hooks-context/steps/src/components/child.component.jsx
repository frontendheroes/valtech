import { useContext } from "react";
import FamilyContext from "../contexts/family.context";

let ChildComp = ()=>{
    let grandGift = useContext(FamilyContext);
    return <div style={ { border : "2px solid grey", margin : "10px", padding:"10px"} }>
                <h1>Child Component</h1>
                {/* <FamilyContext.Consumer>{(val)=><h2>Gift Recieved { val }</h2>}</FamilyContext.Consumer> */}
                <h2>{ grandGift }</h2>
                <h2>{ grandGift }</h2>
                <h2>{ grandGift }</h2>
                <h2>{ grandGift }</h2>
                <h2>{ grandGift }</h2>
            </div>
}

export default ChildComp;