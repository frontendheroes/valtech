import { useState } from "react"
import GrandParentComp from "./components/grandparent.component";
import { UseEffectComp } from "./components/useEffectComp";
import UseReducerComp from "./components/useReducerComp";
import useValtech from "./hooks/useValtech";

export let App = ()=> {
   /*  
   let [power, setPower] = useState(0);
    let [version, setVersion] = useState(0);
    let [rating, setRating] = useState(0); 
    */
    let message = useValtech(4);
    let [state, setState] = useState({ power: 0, version : 0, rating : 0});

    return <div>
                <h1>{ message } | Power is { state.power } | Version is : { state.version } | Rating : { state.rating }</h1>
                <input type="range" onChange={(evt)=> setState({ ...state, power: evt.target.value })} />
                <br />
                <input type="range" onChange={()=> setState({...state, version : state.version+1} )} />
                <br />
                <input type="range" onChange={()=> setState({...state, rating: state.rating+1} )} />
               { state.power < 50 ? <UseEffectComp state={state}/> : <h3>Component Removed</h3> }
               <hr />
               <UseReducerComp></UseReducerComp>
               <hr />
               <GrandParentComp/>
           </div>
}