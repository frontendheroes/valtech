import { Component } from "react";
import ChildComp from "./child.comp";

class App extends Component{
    state = {
        power : 0,
        title : "Component Communication"
    }
   increasePower = ()=>{
    this.setState({
        power : this.state.power+1
    })
   }

   decreasePower = ()=>{
    this.setState({
        power : this.state.power-1
    })
   }

   changeTitle = (ntitle)=>{
    this.setState({
        /* title : "changed" */
        title : ntitle
    })
   }
    render(){
        return <div>
                    <h1>{ this.state.title }</h1>
                    <h2>Power : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.decreasePower }>Decrease Power</button>
                    <hr />
                    <ChildComp changeTitle={this.changeTitle} power={this.state.power}/>
                    <ChildComp changeTitle={this.changeTitle} power={this.state.power}/>
                    <ChildComp changeTitle={this.changeTitle} power={this.state.power}/>
               </div>
        
     }
};

export default App