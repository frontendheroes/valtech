import { Component } from "react";

class App extends Component{
    state = {
        showTerms : false
    }
    toggleConditions = ()=>{
        this.setState({
            showTerms : !this.state.showTerms
        })
    }
    /* render(){
       if(this.state.showTerms){
         return <div>
            <label htmlFor="">Show Terms and Conditions
                <input onChange={this.toggleConditions} type="checkbox" />
            </label>
            <fieldset>
            <legend>Terms & Conditions</legend>
            <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus laborum molestias, assumenda nemo suscipit odio amet fuga eveniet laudantium, aspernatur aliquid ducimus molestiae quaerat voluptatem eligendi autem sunt, dolore obcaecati?
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi voluptas, odio aliquam nostrum rem totam pariatur repudiandae eius at exercitationem tenetur nemo perspiciatis aliquid eligendi mollitia blanditiis voluptatem vitae numquam.
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime aut totam distinctio? Maxime necessitatibus ab earum totam, excepturi provident vel nostrum eius repellat repellendus cum esse mollitia quisquam in explicabo?
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo, nostrum et, quae laudantium sunt porro nesciunt ipsum tempora molestias voluptatum numquam id vitae quos veniam reiciendis perferendis, nemo illum consectetur?
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis, exercitationem laborum voluptatum dignissimos id delectus iure explicabo distinctio, commodi ab soluta earum, dolore consequuntur itaque quam veritatis ea consequatur nemo?
            </p>
         </fieldset>
         </div>
       }else{
         return <div>
             <label htmlFor="">Show Terms and Conditions
                <input onChange={this.toggleConditions} type="checkbox" />
            </label>
         </div>
       }
    } */

    render(){
        return <div>
                    <label htmlFor="">Show Terms and Conditions
                        <input onChange={this.toggleConditions} type="checkbox" />
                    </label>
                    { this.state.showTerms && <fieldset>
                    <legend>Terms & Conditions</legend>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus laborum molestias, assumenda nemo suscipit odio amet fuga eveniet laudantium, aspernatur aliquid ducimus molestiae quaerat voluptatem eligendi autem sunt, dolore obcaecati?
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi voluptas, odio aliquam nostrum rem totam pariatur repudiandae eius at exercitationem tenetur nemo perspiciatis aliquid eligendi mollitia blanditiis voluptatem vitae numquam.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime aut totam distinctio? Maxime necessitatibus ab earum totam, excepturi provident vel nostrum eius repellat repellendus cum esse mollitia quisquam in explicabo?
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo, nostrum et, quae laudantium sunt porro nesciunt ipsum tempora molestias voluptatum numquam id vitae quos veniam reiciendis perferendis, nemo illum consectetur?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis, exercitationem laborum voluptatum dignissimos id delectus iure explicabo distinctio, commodi ab soluta earum, dolore consequuntur itaque quam veritatis ea consequatur nemo?
                    </p>
                </fieldset> }
                </div>
        
     }
};

export default App