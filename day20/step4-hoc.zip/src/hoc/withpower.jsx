import { Component } from "react";

let WithPower = (OriginalComp)=>{
    return class TempComp extends Component{
        state = {
            power : 0,
            version : 0
        }
        increasePowerHandler = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }
        increaseVersionHandler = ()=>{
            this.setState({
                version : this.state.version + 1
            })
        }
        render(){
            return <OriginalComp {...this.props} increaseVersionHandler={ this.increaseVersionHandler } {...this.state} increasePowerHandler={ this.increasePowerHandler } />
        }
    }
}

export default WithPower;